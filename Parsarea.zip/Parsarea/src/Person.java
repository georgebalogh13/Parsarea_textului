public class Person {

    String firstName;
    String lastName;
    String placeOfBirth;

    public Person(String firstName, String lastName, String placeOfBirth){
        this.firstName = firstName;
        this.lastName = lastName;
        this.placeOfBirth = placeOfBirth;
    }


}
