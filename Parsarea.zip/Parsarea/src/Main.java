import java.sql.Array;
import java.util.Arrays;

public class Main {

    public static void main(String[] args){

        String text = "John.Davidson/BelgradeMichaelBarton/KrakowIvan.Perkinson/Moskow";
        text = text.replace(".", "");
        text = text.replace("/", "");
        String[] text1 = text.split("(?=\\p{Upper})");
        System.out.println(Arrays.toString(text1));

        Person[] p = new Person[text1.length/3];
        int something = 0;
        for (int i = 0; i < p.length; i++){
            p[i] = new Person(text1[something++], text1[something++], text1[something++]);
        }

        for (int i = 0; i < p.length; i++){
            System.out.println(p[i].firstName + " " + p[i].lastName + " " + p[i].placeOfBirth);
        }

    }

}
